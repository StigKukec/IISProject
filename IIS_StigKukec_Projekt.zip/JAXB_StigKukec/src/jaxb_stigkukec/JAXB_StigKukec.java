/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jaxb_stigkukec;

import generated.GlobalAirPolution;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;

/**
 *
 * @author Stig
 */
public class JAXB_StigKukec {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        int portNumber = 4925;

     
        try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
            System.out.println("Server čeka na zahtjeve...");

            while (true) {
                Socket clientSocket = null;
                BufferedWriter writer = null;

                try {
                    clientSocket = serverSocket.accept();
                    System.out.println("Primljen zahtjev od klijenta.");
                    OutputStream output = clientSocket.getOutputStream();
                    writer = new BufferedWriter(new OutputStreamWriter(output));

                    InputStream inputStream = clientSocket.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                    JAXBContext jaxbContext = JAXBContext.newInstance(GlobalAirPolution.class);
                    Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

                    Path currentDir = Paths.get("").toAbsolutePath();
                    String schemaPath = currentDir.resolve("xml-resources/jaxb/GlobalAirPolution/GlobalAirPolution.xsd").toString();

                    SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
                    Schema schema = schemaFactory.newSchema(new File(schemaPath));

                    unmarshaller.setSchema(schema);

                    String xmlFilePath = reader.readLine();
                    File xmlFile = new File(xmlFilePath);
                    if (!xmlFile.exists() || !xmlFile.isFile()) {
                        throw new FileNotFoundException("XML datoteka nije pronađena: " + xmlFilePath);
                    }

                    GlobalAirPolution globalAirPolution = (GlobalAirPolution) unmarshaller.unmarshal(xmlFile);

                    writer.write("true,Valid XML");
                    writer.newLine();
                    writer.flush();

                } catch (JAXBException | SAXException ex) {
                    if (writer != null) {
                        String[] separateBegin = ex.toString().split(";"); 
                        String[] separateEnd = separateBegin[3].split("\\]");
                        String[] separateEndpt = separateEnd[0].split(":");
                        String invalidXMLMessage = separateBegin[1] + ";" + separateBegin[2] + "; " + separateEndpt[1].trim();
                        System.err.println(invalidXMLMessage);
                        writer.write("false," + invalidXMLMessage);
                        writer.newLine();
                        writer.flush();
                    }
                } catch (FileNotFoundException ex) {
                    System.err.println("XML datoteka nije pronađena: " + ex.getMessage());
                    if (writer != null) {
                        writer.write("false," + ex.getMessage());
                        writer.newLine();
                        writer.flush();
                    }
                } catch (IOException ex) {
                    System.err.println("Greška pri čitanju ili pisanju: " + ex.getMessage());
                    if (writer != null) {
                        writer.write("false,Error");
                        writer.newLine();
                        writer.flush();
                    }
                } finally {
                    try {
                        if (writer != null) {
                            writer.close();
                        }
                        if (clientSocket != null && !clientSocket.isClosed()) {
                            clientSocket.close();
                        }
                    } catch (IOException ex) {
                        System.err.println("Greška pri zatvaranju tokova ili soketa: " + ex.getMessage());
                    }
                }
            }
        } catch (IOException io) {
            System.err.println("Serverska greška na portu " + portNumber + ": " + io.getMessage());
        }
    }
}

                          