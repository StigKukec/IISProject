/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package xml.rpc.klijent;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

/**
 *
 * @author Stig
 */
public class XMLRPCKlijent {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int portNumber = 4525;

        try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
            System.out.println("Server čeka na zahtjeve...");

            while (true) {
                Socket clientSocket = null;
                BufferedWriter writer = null;

                try {
                    clientSocket = serverSocket.accept();
                    System.out.println("Primljen zahtjev od klijenta.");
                    OutputStream output = clientSocket.getOutputStream();
                    writer = new BufferedWriter(new OutputStreamWriter(output));

                    InputStream inputStream = clientSocket.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                    try {
                        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
                        config.setServerURL(new URL("http://localhost:8081"));
                        config.setEnabledForExtensions(true);
                        config.setContentLengthOptional(false);

                        XmlRpcClient klijent = new XmlRpcClient();
                        klijent.setConfig(config);

                        String city = reader.readLine();
                        Object[] parametri = new Object[]{city};
                        Object[] result = (Object[]) klijent.execute("CityProperty.cityTemperature", parametri);
                        for (Object obj : result) {
                            String str = (String) obj;
                            String[] foundCity = str.split(",");
                            String cityName = foundCity[0];
                            Double cityTemperature = Double.valueOf(foundCity[1]);
                            System.out.println("Grad: " + cityName + ", Temperatura: " + cityTemperature);
                            writer.write("true," + cityName + "," + cityTemperature);
                            writer.newLine();
                        }
                        writer.flush();
                    } catch (XmlRpcException | MalformedURLException ex) {
                        Logger.getLogger(XMLRPCKlijent.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } catch (IOException ex) {
                    System.err.println("Greška pri čitanju ili pisanju: " + ex.getMessage());
                    if (writer != null) {
                        writer.write("false,Error");
                        writer.newLine();
                        writer.flush();
                    }
                } finally {
                    try {
                        if (writer != null) {
                            writer.close();
                        }
                        if (clientSocket != null && !clientSocket.isClosed()) {
                            clientSocket.close();
                        }
                    } catch (IOException ex) {
                        System.err.println("Greška pri zatvaranju tokova ili soketa: " + ex.getMessage());
                    }
                }
            }
        } catch (IOException io) {
            System.err.println("Serverska greška na portu " + portNumber + ": " + io.getMessage());
        }
    }

}
