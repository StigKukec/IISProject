﻿using GlobalAirPolution.Models;
using System.IO;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;

namespace GlobalAirPolution.Repository
{
    public class FileRepository : IFileRepository
    {
        private static readonly string currentDirectory = Directory.GetCurrentDirectory();
        private readonly string dataFilePath = currentDirectory + "\\Resources\\global_air_pollution_data.csv";
        private string partialXmlGeneratedFilePath = currentDirectory + "\\Resources\\";
        public HashSet<City> GetAllData()
        {
            HashSet<City> airPolutionData = new();

            using (FileStream fs = new(dataFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (BufferedStream bf = new(fs))
            using (StreamReader sr = new(bf))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    var data = ParseLine(line);
                    airPolutionData.Add(data);
                }
            }

            return airPolutionData;
        }

        private static City ParseLine(string line)
        {
            ReadOnlySpan<char> span = line.AsSpan();
            var data = new City();

            int index = 0;
            int nextIndex;

            nextIndex = span.IndexOf(',');
            data.Country_name = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.City_name = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Aqi_category = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Co_aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Co_aqi_category = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Ozone_aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Ozone_aqi_category = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.No2_aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.No2_aqi_category = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Pm2half_aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            data.Pm2half_aqi_category = span.ToString();

            return data;
        }


        public List<string> ConvertDataToXMLFile(string search)
        {
            List<string> data = new();
            string xmlPath = partialXmlGeneratedFilePath + Guid.NewGuid() + ".xml";

            GlobalAirPolutionModel globalAirPolution = new()
            {
                City = GetAllData()
            };
            XmlSerializer xmlSerializer = new(typeof(GlobalAirPolutionModel));
            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add("xsi", "http://www.23.org/2001/XMLSchema-instance");

            using (var stringWriter = new StringWriter())
            {
                xmlSerializer.Serialize(stringWriter, globalAirPolution, namespaces);
                string xmlOutput = stringWriter.ToString();
                using (StreamWriter sw = new(xmlPath))
                {
                    if (!File.Exists(xmlPath))
                    {
                        using (FileStream fs = File.Create(xmlPath))
                        {
                            sw.WriteLine(xmlOutput);
                        }
                    }
                    else
                    {
                        sw.WriteLine(xmlOutput);
                    }
                }
                XmlDocument doc = new();
                doc.LoadXml(xmlOutput);

                XmlNamespaceManager nsmgr = new(doc.NameTable);
                nsmgr.AddNamespace("xsi", "http://www.23.org/2001/XMLSchema-instance");

                XmlNodeList nodes = doc.SelectNodes($"//xsi:city[xsi:country_name='{search}']", nsmgr);
                data.Add(xmlPath);
                foreach (XmlNode node in nodes)
                {
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:aqi_value", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:aqi_category", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:co_aqi_value", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:co_aqi_category", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:ozone_aqi_value", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:ozone_aqi_category", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:no2_aqi_value", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:no2_aqi_category", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:pm2half_aqi_value", nsmgr)?.InnerText}");
                    data.Add($"City {node.SelectSingleNode("xsi:city_name", nsmgr)?.InnerText}: {node.SelectSingleNode("xsi:pm2half_aqi_category", nsmgr)?.InnerText}");
                }
                File.Delete(xmlPath);
            }
            return data;
        }
    }
}
