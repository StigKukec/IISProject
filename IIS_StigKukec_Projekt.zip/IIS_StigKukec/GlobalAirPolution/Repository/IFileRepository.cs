﻿using GlobalAirPolution.Models;

namespace GlobalAirPolution.Repository
{
    public interface IFileRepository
    {
        HashSet<City> GetAllData();
        List<string> ConvertDataToXMLFile(string search);
    }
}
