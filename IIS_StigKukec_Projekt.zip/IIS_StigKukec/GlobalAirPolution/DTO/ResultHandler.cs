﻿
using Microsoft.AspNetCore.Mvc;

namespace GlobalAirPolution.DTO
{
    public class ResultHandler
    {
        public ResultHandler(bool result, string resultMessage = null!, ActionResult resultResponse = null!)
        {
            Result = result;
            ResultMessage = resultMessage;
            ResultResponse = resultResponse;
        }

        public bool Result { get; set; }
        public string ResultMessage { get; set; }
        public ActionResult ResultResponse { get; set; }

        public object GetValueFromActionResult(ActionResult actionResult)
        {
            if (actionResult is ObjectResult objectResult)
            {
                return objectResult.Value;
            }

            return actionResult;
        }

        public ResultHandler JsonMessage()
        {
            object objectResultContent = GetValueFromActionResult(ResultResponse);
            if (ResultResponse is ObjectResult objectResult)
            {
                objectResult.Value = new { message = objectResultContent };
                return this;
            }
            return this;
        }
    }

    public class ResultHandler<T> : ResultHandler
    {
        public ResultHandler(bool result, string resultMessage = null!, ActionResult resultResponse = null!) : base(result, resultMessage, resultResponse)
        {
        }

        public ResultHandler(bool result, T entity, string resultMessage = null!, ActionResult resultResponse = null!) : base(result, resultMessage, resultResponse)
        {
            Entity = entity;
        }

        public T? Entity { get; set; }
    }
}
