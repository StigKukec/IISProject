﻿using GlobalAirPolution.Models;

namespace GlobalAirPolution.DTO
{
    public class DemoToken
    {
        public string SerializedToken { get; set; }
        public RefreshToken RefreshToken { get; set; }
    }
    public class Token
    {
        public string SerializedToken { get; set; }
        public string RefreshToken { get; set; }
    }
}
