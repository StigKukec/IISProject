﻿//using Commons.Xml.Relaxng;
using GlobalAirPolution.DTO;
using GlobalAirPolution.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data.Common;
using System.IO;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.ServiceModel.Channels;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;
using Tenuto;

namespace GlobalAirPolution.Services
{
    public class XMLValidator
    {
        private static readonly string xsdValidatorPath = Directory.GetCurrentDirectory() + "\\Resources\\GlobalAirPolution.xsd";
        private static readonly string currentDirectory = Directory.GetCurrentDirectory();
        public ResultHandler ValidateXmlWithXsd(IFormFile file)
        {
            try
            {
                XmlReaderSettings settings = new()
                {
                    ValidationType = ValidationType.Schema
                };

                XmlSchemaSet schemas = new();
                schemas.Add("", xsdValidatorPath);

                settings.Schemas = schemas;

                using MemoryStream ms = new();
                file.CopyTo(ms);
                ms.Seek(0, SeekOrigin.Begin);
                using XmlReader reader = XmlReader.Create(ms, settings);
                while (reader.Read()) ;
                return new ResultHandler(true, resultResponse: new OkObjectResult("XML file is valid."));

            }
            catch (Exception ex)
            {
                ResultHandler result = new(false, ex.Message, new BadRequestObjectResult(ex.Message));
                return result;
            }
        }
        record Result(string Message, bool Valid);

        public ResultHandler ValidateXmlWithRng(IFormFile file)
        {
            try
            {
                TcpClient rngServer = new("localhost", 4926);
                string xmlFilePath = currentDirectory + $"\\Resources\\{Guid.NewGuid()}.xml";
                using (StreamWriter sw = new(xmlFilePath))
                {
                    using (MemoryStream ms = new())
                    {
                        file.CopyTo(ms);
                        sw.WriteLine(Encoding.UTF8.GetString(ms.ToArray()));
                        sw.Flush();
                    }
                }
                byte[] data = Encoding.UTF8.GetBytes(xmlFilePath + "\n");
                rngServer.Client.Send(data, 0, data.Length, SocketFlags.None);
                string response;
                using (StreamReader reader = new StreamReader(rngServer.GetStream()))
                {
                    response = reader.ReadLine();
                }

                File.Delete(xmlFilePath);
                if (response == null)
                {
                    return new ResultHandler(false, "Server response failed.");
                }

                string[] responseDetails = response.Split(',');
                if (responseDetails[0].ToLower().Trim() == "true")
                {
                    return new ResultHandler(true, responseDetails[1], new OkObjectResult(responseDetails[1]));
                }
                return new ResultHandler(false, responseDetails[1], new BadRequestObjectResult(responseDetails[1]));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new ResultHandler(false, ex.Message, new BadRequestObjectResult(ex.Message));
            }
        }


        public ResultHandler ValidateXmlWithJaxb(IFormFile file)
        {
            try
            {
                TcpClient rngServer = new("localhost", 4925);
                string xmlFilePath = currentDirectory + $"\\Resources\\{Guid.NewGuid()}.xml";
                using (StreamWriter sw = new(xmlFilePath))
                {
                    using (MemoryStream ms = new())
                    {
                        file.CopyTo(ms);
                        sw.WriteLine(Encoding.UTF8.GetString(ms.ToArray()));
                        sw.Flush();
                    }
                }
                byte[] data = Encoding.UTF8.GetBytes(xmlFilePath + "\n");
                rngServer.Client.Send(data, 0, data.Length, SocketFlags.None);
                string response;
                using (StreamReader reader = new StreamReader(rngServer.GetStream()))
                {
                    response = reader.ReadLine();
                }

                File.Delete(xmlFilePath);
                if (response == null)
                {
                    return new ResultHandler(false, "Server response failed.");
                }

                string[] responseDetails = response.Split(',');
                if (responseDetails[0].ToLower().Trim() == "true")
                {
                    return new ResultHandler(true, responseDetails[1], new OkObjectResult(responseDetails[1]));
                }
                return new ResultHandler(false, responseDetails[1], new OkObjectResult(responseDetails[1]));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new ResultHandler(false, ex.Message, new BadRequestObjectResult(ex.Message));
            }
        }
        public record CityTemperature(string Temperature, string City);
        public ResultHandler GetCityTemperature(string city)
        {
            try
            {
                TcpClient rngServer = new("localhost", 4525);
                byte[] data = Encoding.UTF8.GetBytes(city + "\n");
                rngServer.Client.Send(data, 0, data.Length, SocketFlags.None);
                List<string> response = new();
                using (StreamReader reader = new StreamReader(rngServer.GetStream()))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        response.Add(line);
                    }
                }
                if (response == null)
                {
                    return new ResultHandler(false, "Server response failed.", new BadRequestObjectResult("Server response failed."));
                }
                List<CityTemperature> cities = new();
                foreach (var foundCity in response)
                {
                    string[] responseDetails = foundCity.Split(',');
                    if (responseDetails[0].ToLower().Trim() == "true")
                    {
                        cities.Add(new CityTemperature(responseDetails[2], responseDetails[1]));
                    }
                }
                if (cities != null)
                {
                    return new ResultHandler<List<CityTemperature>>(true, "Success.", new OkObjectResult(cities));
                }
                return new ResultHandler(false, "Server response failed.", new BadRequestObjectResult("Server response failed."));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new ResultHandler(false, ex.Message, new BadRequestObjectResult(ex.Message));
            }
        }

    }
}
