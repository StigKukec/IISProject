﻿using GlobalAirPolution.DTO;
using GlobalAirPolution.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace GlobalAirPolution.Services
{
    public class JwtToken
    {
        private readonly IConfiguration _configuration;
        private readonly List<User> users;
        private readonly IMemoryCache _memoryCache;
        public JwtToken(IConfiguration configuration, IMemoryCache memoryCache)
        {
            _configuration = configuration;
            users = new()
            {
                new User("Mario","asdk"),
                new User("Marko","asdk1"),
                new User("Ivan","asdk2")
            };
            _memoryCache = memoryCache;
        }
        public static string GetSecurityToken()
        {
            byte[] securityToken = RandomNumberGenerator.GetBytes(256 / 8);
            string b64SecToken = Convert.ToBase64String(securityToken);
            return b64SecToken;
        }
        private ResultHandler<DemoToken> AssignToken(string username)
        {
            try
            {
                var jwtKey = _configuration["JWT:Key"];
                var jwtKeyBytes = Encoding.UTF8.GetBytes(jwtKey);

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                        new (ClaimTypes.Name, Convert.ToString(username))
                    }),
                    Issuer = _configuration["JWT:Issuer"],
                    Audience = _configuration["JWT:Audience"],
                    Expires = DateTime.UtcNow.AddMinutes(25),
                    SigningCredentials = new SigningCredentials(
                        new SymmetricSecurityKey(jwtKeyBytes),
                        SecurityAlgorithms.HmacSha256Signature)
                };
                var tokenHandler = new JwtSecurityTokenHandler();
                var token = tokenHandler.CreateToken(tokenDescriptor);
                var serializedToken = tokenHandler.WriteToken(token);
                User user = users.First(x => x.Username.Equals(username));
                DemoToken demoToken = new()
                {
                    SerializedToken = serializedToken,
                    RefreshToken = new RefreshToken()
                    {
                        Token = GetSecurityToken(),
                        IsUsed = false,
                        UserID = user.UserID,
                        ValidUntil = DateTime.Now.AddDays(1)
                    }
                };
                return new ResultHandler<DemoToken>(true, demoToken, resultResponse: new OkObjectResult(demoToken));
            }
            catch (Exception ex)
            {
                return new ResultHandler<DemoToken>(false, resultResponse: new BadRequestObjectResult(ex.Message));
            }
        }

        private bool Authentication(string username, string password)
        {
            bool autheticate = false;
            foreach (User user in users)
            {
                if (username.Equals(user.Username) && password.Equals(user.Password))
                {
                    autheticate = true;
                }
            }
            return autheticate;
        }

        public ResultHandler<DemoToken> SignIn(string username, string password)
        {
            if (!Authentication(username, password))
            {
                return new ResultHandler<DemoToken>(false, resultResponse: new BadRequestObjectResult("Wrong username or password."));
            }
            ResultHandler<DemoToken> token = AssignToken(username);
            _memoryCache.Set(username, token.Entity, TimeSpan.FromMinutes(10));
            return token;
        }
        public ResultHandler LogOut(string username, string refreshToken)
        {
            try
            {
                if (_memoryCache.TryGetValue(username, out DemoToken cachedValue))
                {
                    if (cachedValue != null && cachedValue.RefreshToken.Token == refreshToken)
                    {
                        _memoryCache.Remove(username);
                        return new ResultHandler(true, resultResponse: new OkObjectResult("message:Successfuly logged out."));
                    }
                }
                return new ResultHandler<DemoToken>(false, resultResponse: new UnauthorizedResult());
            }
            catch (Exception ex)
            {
                return new ResultHandler(false, resultResponse: new BadRequestObjectResult(ex.Message));
            }
        }

        public ResultHandler<DemoToken> RefreshAccessToken(string username, string refreshToken)
        {
            if (_memoryCache.TryGetValue(username, out DemoToken cachedValue))
            {
                if (cachedValue != null && cachedValue.RefreshToken.Token == refreshToken)
                {
                    ResultHandler<DemoToken> permissionTokens = AssignToken(username);
                    return permissionTokens;
                }
            }
            return new ResultHandler<DemoToken>(false, resultResponse: new UnauthorizedResult());
        }
    }
}
