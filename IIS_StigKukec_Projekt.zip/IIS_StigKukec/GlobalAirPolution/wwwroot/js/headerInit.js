﻿const header = ` <div id="Header">
        <div class="prviDioHeader">

            <button id="logout-btn">LogOut</button>
            <a href="https://localhost:7159/Signin.html" target="_self" id="signIn">Sign in</a>
            <a href="https://localhost:7159/XsdValidator.html" target="_self" id="xsd">Xsd validator</a>
            <a href="https://localhost:7159/RngValidator.html" target="_self" id="rng"> Relax NG validator</a>
            <a href="https://localhost:7159/Soap.html" target="_self" id="soap">SOAP</a>
            <a href="https://localhost:7159/Xml-Rpc.html" target="_self" id="xmlRpc">XML-RPC</a>
            <a href="https://localhost:7159/RefreshToken.html" id="refreshToken">Refresh access token</a>

        </div>
        <div class="drugiDioHeader">

            <a href="" class="notSignedIn">Not Signed in</a>
            <a href="" class="usernameprefix">Signed in as:</a>
            <a href="" id="user_name"></a>

        </div>
    </div>
`;

function addHeader() {
    document.body.insertAdjacentHTML("afterbegin", header);
    //Ime korisnika
    var imeKorisnika = localStorage.getItem("user_name");
    document.getElementById("user_name").innerHTML = imeKorisnika;
    //Ime korisnika

    //logout
    $('#logout-btn').click(function () {
        var username = localStorage.getItem("user_name");
        var refreshToken = localStorage.getItem("refToken");
        const formData = {
            username,
            refreshToken
        };
        $.ajax({
            type: 'POST',
            url: `https://localhost:7159/api/GlobalAirPolution/logout`,
            data: formData,
            success: function (data) {
                console.log("Succesfully logged out.");
                const message = `<h1>${data.message}</h1>`;
                //$("#displayId").append(message);
            },
            error: function (data) {
                console.error(data.responseText);
                var obj = JSON.parse(data.responseText);
                const message = `<h1>${obj.message}</h1>`;
                //$("#displayId").append(message);
            }
        });
        var username = localStorage.removeItem("user_name");
        var refreshToken = localStorage.removeItem("refToken");
        window.location.href = 'https://localhost:7159/Signin.html';
    });
    $(document).ready(function () {
        if (localStorage.getItem("jwt") && localStorage.getItem("refToken")) {
            $('.notSignedIn').hide();
            $('.usernameprefix').show();
            $('#username').show();
            $('#signIn').hide();
            $('#logout-btn').show();
        } else {
            localStorage.removeItem("user_name");
            $('.usernameprefix').hide();
            $('#user_name').hide();
            $('#logout-btn').hide();
            $('.notSignedIn').show();
            $('#signIn').show();
        }
    });
    //logout
}

document.addEventListener("DOMContentLoaded", addHeader);
