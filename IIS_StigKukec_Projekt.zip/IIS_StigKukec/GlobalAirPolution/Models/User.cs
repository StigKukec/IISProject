﻿namespace GlobalAirPolution.Models
{
    public class User
    {
        private readonly int id;
        public User(string username, string password)
        {
            Username = username;
            Password = password;
            UserID = ++id;
        }

        public int UserID { get; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
