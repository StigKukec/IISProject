﻿using System.Xml.Serialization;

namespace GlobalAirPolution.Models
{
    [XmlRoot("globalAirPolution", Namespace = "http://www.23.org/2001/XMLSchema-instance")]
    public class GlobalAirPolutionModel
    {
        [XmlElement("city")]
        public HashSet<City> City { get; set; }
    }
}
