﻿namespace GlobalAirPolution.Models
{
    public class RefreshToken
    {
        public string Token { get; set; }
        public DateTime ValidUntil { get; set; }
        public bool IsUsed { get; set; }
        public int UserID { get; set; }
    }
}
