﻿namespace GlobalAirPolution.Models
{
    public class UserSignInRequest
    {
        public string Username { get; set; } = null!;

        public string Password { get; set; } = null!;

    }
}
