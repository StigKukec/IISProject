﻿using GlobalAirPolution.DTO;
using GlobalAirPolution.Models;
using GlobalAirPolution.Repository;
using GlobalAirPolution.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServiceReferenceGAP;
using System.Net.Sockets;
using System.Security.Claims;
using System.Xml;

namespace GlobalAirPolution.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GlobalAirPolutionController : ControllerBase
    {
        private readonly IFileRepository _fileRepository;
        private readonly XMLValidator _xmlValidator;
        private readonly JwtToken _jwt;
        public GlobalAirPolutionController(IFileRepository fileRepository, JwtToken jwt)
        {
            _fileRepository = fileRepository;
            _xmlValidator = new();
            _jwt = jwt;
        }

        [HttpPost("signin")]
        public ActionResult SignIn([FromBody] UserSignInRequest signInRequest)
        {
            ResultHandler result = _jwt.SignIn(signInRequest.Username, signInRequest.Password);
            return result.JsonMessage().ResultResponse;
        }

        public record LogOutRequest(string Username, string RefreshToken);
        [HttpPost("logout")]
        public ActionResult LogOut([FromBody] LogOutRequest request)
        {
            ResultHandler result = _jwt.LogOut(request.Username, request.RefreshToken);
            return result.JsonMessage().ResultResponse;
        }

        public record RefreshTokenRequest(string Username, string RefreshToken);
        [AllowAnonymous]
        [HttpPost("refreshtoken")]
        public ActionResult RefreshToken([FromBody] RefreshTokenRequest request)
        {
            ResultHandler<DemoToken> result = _jwt.RefreshAccessToken(request.Username, request.RefreshToken);
            return result.JsonMessage().ResultResponse;
        }

        [HttpGet("getdata")]
        public ActionResult GetData()
        {
            return Ok(_fileRepository.GetAllData());
        }

        [HttpGet("generatexmlfile")]
        public ActionResult GenerateXMLFile(string search)
        {
            return Ok(_fileRepository.ConvertDataToXMLFile(search));
        }

        [HttpPost("xsd")]
        public ActionResult XSD([FromForm] IFormFile file)
        {
            return _xmlValidator.ValidateXmlWithXsd(file).JsonMessage().ResultResponse;
        }

        [HttpPost("rng")]
        public ActionResult RNG([FromForm] IFormFile file)
        {
            ResultHandler result = _xmlValidator.ValidateXmlWithRng(file);
            return result.JsonMessage().ResultResponse;
        }

        [HttpPost("jaxb")]
        public ActionResult JAXB([FromForm] IFormFile file)
        {
            ResultHandler result = _xmlValidator.ValidateXmlWithJaxb(file);
            return result.JsonMessage().ResultResponse;
        }

        [HttpGet("xml-rpc")]
        public ActionResult Xmlrpc(string city)
        {
            ResultHandler result = _xmlValidator.GetCityTemperature(city);
            return result.JsonMessage().ResultResponse;
        }

        [Authorize]
        [HttpGet("soap")]
        public async Task<ActionResult> SOAP(string country)
        {
            try
            {
                GlobalAirPolutionXPathClient globalAirPolutionXPathClient = new();
                return Ok(await globalAirPolutionXPathClient.ConvertDataToXMLFileAsync(country));
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                ResultHandler result = new(false, ex.Message, new BadRequestObjectResult("Can't fetch air polution data for every city at the moment."));
                return result.JsonMessage().ResultResponse;
            }
        }
    }
}
