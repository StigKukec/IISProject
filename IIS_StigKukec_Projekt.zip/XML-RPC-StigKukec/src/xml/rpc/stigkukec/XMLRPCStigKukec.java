/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package xml.rpc.stigkukec;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.server.PropertyHandlerMapping;
import org.apache.xmlrpc.server.XmlRpcServer;
import org.apache.xmlrpc.server.XmlRpcServerConfigImpl;
import org.apache.xmlrpc.webserver.WebServer;

/**
 *
 * @author Stig
 */
public class XMLRPCStigKukec {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            System.out.println("Server se pokreće...");
            WebServer server = new WebServer(8081);

            XmlRpcServer xmlServer = server.getXmlRpcServer();
            PropertyHandlerMapping phm = new PropertyHandlerMapping();
            phm.addHandler("CityProperty", CityProperty.class);
            xmlServer.setHandlerMapping(phm);

            XmlRpcServerConfigImpl config = (XmlRpcServerConfigImpl) xmlServer.getConfig();
            config.setEnabledForExtensions(true);
            config.setContentLengthOptional(false);

            server.start();
            System.out.println("Uspješno pokrenut server.");
            System.out.println("Čekam zahtjeve.");
        } catch (IOException | XmlRpcException ex) {
            Logger.getLogger(XMLRPCStigKukec.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
