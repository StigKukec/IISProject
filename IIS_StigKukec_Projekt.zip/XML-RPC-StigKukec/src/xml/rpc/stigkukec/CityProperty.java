/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xml.rpc.stigkukec;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Stig
 */
public class CityProperty {
 
    public List<String> cityTemperature(String city) {
        List<String> cityTemperatures = new ArrayList();
        try {
            String urlString = "https://vrijeme.hr/hrvatska_n.xml";
            URL url = new URL(urlString);
            InputStream stream = url.openStream();

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            
            Document doc = builder.parse(stream);
            doc.getDocumentElement().normalize();

            System.out.println("Zaprimljen zahtjev...");

            NodeList gradList = doc.getElementsByTagName("Grad");

            for (int i = 0; i < gradList.getLength(); i++) {
                Node gradNode = gradList.item(i);

                if (gradNode.getNodeType() == Node.ELEMENT_NODE) {
                    org.w3c.dom.Element gradElement = (org.w3c.dom.Element) gradNode;
                    String gradIme = gradElement.getElementsByTagName("GradIme").item(0).getTextContent();
                    if (gradIme == null ? city == null : gradIme.startsWith(city)) {
                        Double cityTemp = 400.0;
                        String temp = gradElement.getElementsByTagName("Temp").item(0).getTextContent();
                        cityTemp = Double.valueOf(temp);
                        if (cityTemp != 400.0) {
                            cityTemperatures.add(gradIme + "," + cityTemp);
                        }
                    }
                }
            }
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
        }
        System.out.println(cityTemperatures.size());
        return cityTemperatures;
    }
}
