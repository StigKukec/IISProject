/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package hr.algebra.relaxng.stigkukec;

import com.thaiopensource.validate.ValidationDriver;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author Stig
 */
public class RelaxNGStigKukec {

    public static void main(String[] args) {
        int portNumber = 4926;

        try (ServerSocket serverSocket = new ServerSocket(portNumber)) {

            while (true) {
                Socket clientSocket = null;
                BufferedWriter writer = null;
                System.out.println("Server čeka na zahtjeve...");
                try {
                    clientSocket = serverSocket.accept();
                    System.out.println("Primljen zahtjev od klijenta.");
                    OutputStream output = clientSocket.getOutputStream();
                    writer = new BufferedWriter(new OutputStreamWriter(output));

                    InputStream inputStream = clientSocket.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                    Path currentDir = Paths.get("").toAbsolutePath();
                    String rngFilePath = currentDir + "/src/main/java/hr/algebra/relaxng/stigkukec/resources/GlobalAirpolution.rng";

                    String xmlFilePath = reader.readLine();
                    File xmlFile = new File(xmlFilePath);
                    if (!xmlFile.exists() || !xmlFile.isFile()) {
                        throw new FileNotFoundException("XML datoteka nije pronađena: " + xmlFilePath);
                    }
                    InputStream rngInputStream = new FileInputStream(rngFilePath);
                    InputSource relaxNG = new InputSource();
                    InputSource xml = new InputSource(xmlFilePath);
                    relaxNG.setByteStream(rngInputStream);

                    ValidationDriver rngValidation = new ValidationDriver();

                    try {
                        rngValidation.loadSchema(relaxNG);
                        boolean result = rngValidation.validate(xml);

                        if (result) {
                            System.out.println("XML is valid.");
                            writer.write(result + ",Valid XML");
                            writer.newLine();
                            writer.flush();
                        } else {
                            System.out.println("XML is NOT valid.");
                            writer.write(result + ",Invalid XML");
                            writer.newLine();
                            writer.flush();

                        }
                    } catch (SAXException ex) {
                        System.out.println(ex.getMessage());
                        writer.write("false," + ex.getMessage());
                        writer.newLine();
                        writer.flush();
                        Logger.getLogger(RelaxNGStigKukec.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } catch (FileNotFoundException ex) {
                    System.err.println("XML datoteka nije pronađena: " + ex.getMessage());
                    if (writer != null) {
                        writer.write("false," + ex.getMessage());
                        writer.newLine();
                        writer.flush();
                    }
                } catch (IOException ex) {
                    System.err.println("Greška pri čitanju ili pisanju: " + ex.getMessage());
                    if (writer != null) {
                        writer.write("false,Error");
                        writer.newLine();
                        writer.flush();
                    }
                } finally {
                    try {
                        if (writer != null) {
                            writer.close();
                        }
                        if (clientSocket != null && !clientSocket.isClosed()) {
                            clientSocket.close();
                        }
                    } catch (IOException ex) {
                        System.err.println("Greška pri zatvaranju tokova ili soketa: " + ex.getMessage());
                    }
                }
            }
        } catch (IOException io) {
            System.err.println("Serverska greška na portu " + portNumber + ": " + io.getMessage());
        }
    }
}
