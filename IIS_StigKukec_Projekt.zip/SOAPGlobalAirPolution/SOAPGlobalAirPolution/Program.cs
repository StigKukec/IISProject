using SoapCore;
using SOAPGlobalAirPolution.XPath;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddControllers();

builder.Services.AddSingleton<IGlobalAirPolutionXPath, GlobalAirPolutionXPath>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();


app.MapControllers();

app.UseSoapEndpoint<IGlobalAirPolutionXPath>("/ServiceXPath.asmx", new SoapEncoderOptions());

app.Run();