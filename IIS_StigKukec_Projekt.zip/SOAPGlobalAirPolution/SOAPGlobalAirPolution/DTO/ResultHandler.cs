﻿namespace SOAPGlobalAirPolution.DTO
{
    public class ResultHandler
    {
        public ResultHandler(bool result, string resultMessage)
        {
            Result = result;
            ResultMessage = resultMessage;
        }

        public bool Result { get; set; }
        public string ResultMessage { get; set; } = null!;
    }
    public class ResultHandler<T> : ResultHandler
    {

        public ResultHandler(bool result, string resultMessage, T enitity) : base(result, resultMessage)
        {
            Enitity = enitity;
        }

        public T Enitity { get; set; }
    }
}
