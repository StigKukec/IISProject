﻿using System.Xml.Serialization;

namespace SOAPGlobalAirPolution.Models
{
    public class City
    {
        [XmlElement("country_name")]
        public string Country_name { get; set; }

        [XmlElement("aqi_value")]
        public string Aqi_value { get; set; }

        [XmlElement("city_name")]
        public string City_name { get; set; }

        [XmlElement("aqi_category")]
        public string Aqi_category { get; set; }

        [XmlElement("co_aqi_value")]
        public string Co_aqi_value { get; set; }

        [XmlElement("co_aqi_category")]
        public string Co_aqi_category { get; set; }

        [XmlElement("ozone_aqi_value")]
        public string Ozone_aqi_value { get; set; }

        [XmlElement("ozone_aqi_category")]
        public string Ozone_aqi_category { get; set; }

        [XmlElement("no2_aqi_value")]
        public string No2_aqi_value { get; set; }

        [XmlElement("no2_aqi_category")]
        public string No2_aqi_category { get; set; }

        [XmlElement("pm2half_aqi_value")]
        public string Pm2half_aqi_value { get; set; }

        [XmlElement("pm2half_aqi_category")]
        public string Pm2half_aqi_category { get; set; }

        public override bool Equals(object? obj)
        {
            return obj is City city &&
                   Country_name == city.Country_name &&
                   Aqi_value == city.Aqi_value &&
                   City_name == city.City_name &&
                   Aqi_category == city.Aqi_category &&
                   Co_aqi_value == city.Co_aqi_value &&
                   Co_aqi_category == city.Co_aqi_category &&
                   Ozone_aqi_value == city.Ozone_aqi_value &&
                   Ozone_aqi_category == city.Ozone_aqi_category &&
                   No2_aqi_value == city.No2_aqi_value &&
                   No2_aqi_category == city.No2_aqi_category &&
                   Pm2half_aqi_value == city.Pm2half_aqi_value &&
                   Pm2half_aqi_category == city.Pm2half_aqi_category;
        }

        public override int GetHashCode()
        {
            HashCode hash = new HashCode();
            hash.Add(Country_name);
            hash.Add(Aqi_value);
            hash.Add(City_name);
            hash.Add(Aqi_category);
            hash.Add(Co_aqi_value);
            hash.Add(Co_aqi_category);
            hash.Add(Ozone_aqi_value);
            hash.Add(Ozone_aqi_category);
            hash.Add(No2_aqi_value);
            hash.Add(No2_aqi_category);
            hash.Add(Pm2half_aqi_value);
            hash.Add(Pm2half_aqi_category);
            return hash.ToHashCode();
        }
    }
}
