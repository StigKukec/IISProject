﻿using System.Xml.Serialization;
using System.Xml;
using SOAPGlobalAirPolution.Models;
using System.Net.Sockets;
using SOAPGlobalAirPolution.DTO;
using System.Text;
using SoapCore;
using System.Reflection.PortableExecutable;
using System.ComponentModel.DataAnnotations;

namespace SOAPGlobalAirPolution.XPath
{
    public class GlobalAirPolutionXPath : IGlobalAirPolutionXPath
    {
        private static readonly string currentDirectory = Directory.GetCurrentDirectory();
        private readonly string dataFilePath = currentDirectory + "\\Resources\\global_air_pollution_data.csv";
        private string partialXmlGeneratedFilePath = currentDirectory + "\\Resources\\";
        private HashSet<City> GetAllData()
        {
            HashSet<City> airPolutionData = new();

            using (FileStream fs = new FileStream(dataFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (BufferedStream bf = new BufferedStream(fs))
            using (StreamReader sr = new StreamReader(bf))
            {
                string line;
                sr.ReadLine();
                while ((line = sr.ReadLine()) != null)
                {
                    var data = ParseLine(line);
                    airPolutionData.Add(data);
                }
            }

            return airPolutionData;
        }

        private static City ParseLine(string line)
        {
            ReadOnlySpan<char> span = line.AsSpan();
            var data = new City();

            int index = 0;
            int nextIndex;

            nextIndex = span.IndexOf(',');
            data.Country_name = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.City_name = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Aqi_category = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Co_aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Co_aqi_category = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Ozone_aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Ozone_aqi_category = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.No2_aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.No2_aqi_category = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            nextIndex = span.IndexOf(',');
            data.Pm2half_aqi_value = span.Slice(0, nextIndex).ToString();
            span = span.Slice(nextIndex + 1);

            data.Pm2half_aqi_category = span.ToString();

            return data;
        }

        public List<City> ConvertDataToXMLFile(string search)
        {
            List<City> data = new();
            string xmlPath = partialXmlGeneratedFilePath + Guid.NewGuid() + ".xml";

            GlobalAirPolutionModel globalAirPolution = new()
            {
                City = GetAllData()
            };
            XmlSerializer xmlSerializer = new(typeof(GlobalAirPolutionModel));
            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add("xsi", "http://www.w3.org/2001/XMLSchema-instance");
            var settings = new XmlWriterSettings
            {
                Encoding = new UTF8Encoding(false),
                Indent = true,
                OmitXmlDeclaration = false
            };

            using (var stream = new MemoryStream())
            {
                using (var writer = XmlWriter.Create(stream, settings))
                {
                    xmlSerializer.Serialize(writer, globalAirPolution, namespaces);
                }

                string xmlOutput = Encoding.UTF8.GetString(stream.ToArray());
                string[] xmlOutputDetails = xmlOutput.Split("xmlns=\"http://www.23.org/2001/XMLSchema-instance\"");
                xmlOutput = xmlOutputDetails[0] + xmlOutputDetails[1];
                using (StreamWriter sw = new(xmlPath))
                {
                    sw.WriteLine(xmlOutput);
                }
                ResultHandler validationResult = new(false, "Could not complete proccess.");
                using (FileStream fs = new(xmlPath, FileMode.Open))
                {
                    validationResult = ValidateXmlWithJaxb(fs);
                }
                File.Delete(xmlPath);
                if (!validationResult.Result)
                {
                    Console.WriteLine($"Failed to validate xml. Message: {validationResult.ResultMessage}");
                    return data;
                }

                XmlDocument doc = new();
                doc.LoadXml(xmlOutput);

                XmlNamespaceManager nsmgr = new(doc.NameTable);
                nsmgr.AddNamespace("xsi", "http://www.3.org/2001/XMLSchema-instance");

                XmlNodeList nodes = doc.SelectNodes($"//city[country_name='{search}']", nsmgr);
                foreach (XmlNode node in nodes)
                {
                    data.Add(new City()
                    {
                        Aqi_category = node.SelectSingleNode("aqi_category", nsmgr)?.InnerText,
                        Aqi_value = node.SelectSingleNode("aqi_value", nsmgr)?.InnerText,
                        City_name = node.SelectSingleNode("city_name", nsmgr)?.InnerText,
                        Country_name = node.SelectSingleNode("country_name", nsmgr)?.InnerText,
                        Co_aqi_category = node.SelectSingleNode("co_aqi_category", nsmgr)?.InnerText,
                        Co_aqi_value = node.SelectSingleNode("co_aqi_value", nsmgr)?.InnerText,
                        No2_aqi_category = node.SelectSingleNode("no2_aqi_category", nsmgr)?.InnerText,
                        No2_aqi_value = node.SelectSingleNode("no2_aqi_value", nsmgr)?.InnerText,
                        Ozone_aqi_category = node.SelectSingleNode("ozone_aqi_category", nsmgr)?.InnerText,
                        Ozone_aqi_value = node.SelectSingleNode("ozone_aqi_value", nsmgr)?.InnerText,
                        Pm2half_aqi_category = node.SelectSingleNode("pm2half_aqi_category", nsmgr)?.InnerText,
                        Pm2half_aqi_value = node.SelectSingleNode("pm2half_aqi_value", nsmgr)?.InnerText
                    });
                }
            }
            return data;
        }
        private static ResultHandler ValidateXmlWithJaxb(Stream file)
        {
            try
            {
                TcpClient rngServer = new("localhost", 4925);
                string xmlFilePath = currentDirectory + $"\\Resources\\{Guid.NewGuid()}.xml";
                using (StreamWriter sw = new(xmlFilePath))
                {
                    using (MemoryStream ms = new())
                    {
                        file.CopyTo(ms);
                        sw.WriteLine(Encoding.UTF8.GetString(ms.ToArray()));
                        sw.Flush();
                    }
                }
                byte[] data = Encoding.UTF8.GetBytes(xmlFilePath + "\n");
                rngServer.Client.Send(data, 0, data.Length, SocketFlags.None);
                string response;
                using (StreamReader reader = new StreamReader(rngServer.GetStream()))
                {
                    response = reader.ReadLine();
                }

                File.Delete(xmlFilePath);
                if (response == null)
                {
                    return new ResultHandler(false, "Server response failed.");
                }

                string[] responseDetails = response.Split(',');
                if (responseDetails[0].ToLower().Trim() == "true")
                {
                    return new ResultHandler(true, responseDetails[1]);
                }
                return new ResultHandler(false, responseDetails[1]);
            }
            catch (Exception ex)
            {
                return new ResultHandler(false, ex.Message);
            }
        }
    }
}
