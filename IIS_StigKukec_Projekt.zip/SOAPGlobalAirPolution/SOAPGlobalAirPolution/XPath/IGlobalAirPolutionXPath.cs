﻿using SOAPGlobalAirPolution.DTO;
using SOAPGlobalAirPolution.Models;
using System.ServiceModel;

namespace SOAPGlobalAirPolution.XPath
{
    [ServiceContract]
    public interface IGlobalAirPolutionXPath
    {
        [OperationContract]
        List<City> ConvertDataToXMLFile(string search);
    }
}
